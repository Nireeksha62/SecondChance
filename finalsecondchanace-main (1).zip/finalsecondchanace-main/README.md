# secondChance
This project is to enable people to easily access, be made aware and utilize the various  ‘previously-owned’ everyday items and hostel necessities to get the best out of waste, at a fair price,  primarily focused on the student community including hostels like that of MIT Manipal.
